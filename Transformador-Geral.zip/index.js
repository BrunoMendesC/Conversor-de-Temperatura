let a = prompt("O que vc deseja converter?");

switch(a){
  case 'kelvin':
    let k = parseFloat(prompt("Digite a temperatura em kelvin: "));
    let c = k-273.15;
    console.log("Esta é a temperatura em Celsius: "+c+"°");
    let e = (k-273.15)*1.8+32;
    console.log("Esta é a temperatura em Fahrenheit: "+e+"°F"); 
    break;
    
  case 'celsius':
    let b = parseFloat(prompt("Digite a temperatura em Celsius: "));
    let d = b+273.15;
    console.log("Esta é a temperatura em Kelvin: "+d+" K");
    let f = b*1.8+32;
    console.log("Esta é a temperatura em Fahrenheit: "+f+"°F"); 
    break;
    
  case 'fahrenheit':
    let z = parseFloat(prompt("Digite a temperatura em Fahrenheit: "));
    let y = (z-32)/1.8;
    console.log("Esta é a temperatura em Celsius: "+y+"°");
    let u = (z+459.67)*5/9;
    console.log("Esta é a temperatura em Kelvin: "+u+" K"); 
    break;   
}